import axios from 'axios'
import * as Config from '../configs/api'
import { Alert } from 'react-native'

export default async function callMockApi(endpoint, method = 'GET', body = null) {
  try {
    const response = await axios({
      method: method,
      url: `${Config.BASE_URL}/${endpoint}`,
      data: body
    }).then(res => {
      return res.data
    })
    return response
  } catch (e) {
    Alert.alert("Connection Error", "Could not fetch data from API")
  }
};
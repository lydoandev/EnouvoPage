

import React, { Component } from 'react'
import { Text, FlatList, SectionList, ActivityIndicator, ScrollView, StyleSheet, Alert } from "react-native";
import ItemTask from './ItemTask';
import FormAddNew from './FormAddNew';
import axios from 'axios'
import callMockAPI from "../../utils/callMockAPI"

export default class ListTask extends Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      datas: [
      ],
      error: null
    }
  }

  componentDidMount() {
    this.getData();
  }

  getData = async () => {

    var data = await callMockAPI("tasks");
    this.setState({
      datas: this.sort(data),
      loading: true
    });
  }

  addNewTask = async (taskItem) => {
    var { task, date } = taskItem;
    var { datas } = this.state;
    var found = datas.findIndex(item => item.date == date);

    var ids = [];
    datas.map(item => {
      item.data.map(a => {
        ids.push(a.id)
      })
    });

    var maxId = Math.max(...ids);

    if (found != -1) {
      datas[found].data.push({
        id: maxId + 1,
        task,
        status: false
      });
      await callMockAPI("tasks/" + datas[found].id, "DELETE");
      await callMockAPI("tasks/", "POST", datas[found]);
    } else {
      var maxIdSection = Math.max(...datas.map(item => item.id));

      callMockAPI("tasks/", "POST", {
        id: maxIdSection + 1,
        date,
        data: [{
          id: maxId + 1,
          task,
          status: false
        }]
      });
    }
    this.getData();
  }

  deleteItem = async (id) => {
    let indexItem;
    var { datas } = this.state;
    datas.forEach(async (section, index) => {
      indexItem = section.data.findIndex(task => task.id == id);
      if (indexItem != -1) {
        section.data.splice(indexItem, 1);

        if (section.data.length > 0) {
          await callMockAPI("tasks/" + section.id, "DELETE");
          await callMockAPI("tasks/", "POST", section);
        } else {
          await callMockAPI("tasks/" + section.id, "DELETE");
        }
      }
    });
    this.getData();
  }

  isCompleted = async (id, status) => {
    console.log("Status", status)
    let indexItem;
    var { datas } = this.state;
    datas.forEach(async (section, index) => {
      indexItem = section.data.findIndex(task => task.id == id);
      if (indexItem != -1) {
        section.data[indexItem].status = status;
        await callMockAPI("tasks/" + section.id, "PUT", section);
      }
    });
    this.getData();
  }

  sort = (datas) => {

    datas.sort((a, b) => {
      var dateA = new Date(a.date);
      var dateB = new Date(b.date);
      return dateA > dateB ? 1 : -1;
    });
    return datas
  }

  render() {
    const { datas, loading } = this.state;

    if (!loading) {
      return (<ActivityIndicator size="large" color="#0000ff" />)
    }
    return (
      <ScrollView style={styles.taskList}>
        <FormAddNew addNewTask={this.addNewTask}></FormAddNew>
        <SectionList
          sections={datas}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item }) => <ItemTask item={item} deleteItem={this.deleteItem} isCompleted={this.isCompleted} />}
          renderSectionHeader={({ section: { date } }) => (
            <Text style={styles.dateText}>{date}</Text>
          )}
        />
      </ScrollView>
    )
  }
}

const styles = StyleSheet.create({
  taskList: {
    flex: 1,
    paddingHorizontal: 10,
    flexDirection: 'column'
  },
  dateText: {
    fontSize: 20,
    fontWeight: "bold"
  }
})
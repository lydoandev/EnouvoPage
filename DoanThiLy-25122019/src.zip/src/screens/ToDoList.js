import React, { Component } from 'react'
import ListTask from '../components/ToDoList/ListTask'

export default class ToDoList extends Component {
  render() {
    return (
      <ListTask></ListTask>
    )
  }
}

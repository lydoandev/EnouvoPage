import React, { Component } from 'react'
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView } from "react-native"
import InputText from '../components/ToDoList/InputText'
import Title from '../components/ToDoList/Title'
import { Navigation } from 'react-native-navigation';
import { bottomTabs } from "../configs/bottomTabs"

export default class LogIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      pass: ""
    }
  }
  getData = (name, text) => {
    this.setState({
      [name]: text
    })
  }

  login = () => {
    Navigation.setRoot({
      root: {
        bottomTabs
      }
    });
  }

  render() {
    var { username, pass } = this.state;
    return (
      <ScrollView style={{ flex: 1, margin: 20, flexDirection: 'column' }}>
        <View style={styles.titleContent}><Text style={{ fontSize: 35 }}>ĐĂNG NHẬP</Text></View>
        <View style={{ flex: 1, marginTop: 50, marginBottom: 5 }}>
          <Title title="Tên tài khoản *"></Title>
          <InputText name="username" value={username} getData={this.getData}></InputText>
        </View>
        <View style={{ flex: 1, marginBottom: 5, }}>
          <Title title="Mật khẩu *"></Title>
          <InputText pass={true} name="pass" value={pass} getData={this.getData}></InputText>
        </View>
        <View style={styles.buttonContent}>
          <TouchableOpacity style={styles.btnLogin} onPress={this.login}><Text style={styles.loginText}>LOGIN</Text></TouchableOpacity>
          <TouchableOpacity style={styles.btnSignUp} onPress={this.signUp}><Text style={styles.signUpText}>SIGN UP</Text></TouchableOpacity>
        </View>
      </ScrollView>
    )
  }
}
const styles = StyleSheet.create({
  titleContent: {
    alignItems: "center",
    justifyContent: "center",
  },
  buttonContent: {
    height: 45,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    margin: 20
  },
  btnSignUp: {
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#67B6BB'
  },
  signUpText: {
    color: '#67B6BB',
    textAlign: 'center',
  },
  btnLogin: {
    width: 100,
    justifyContent: 'center',
    backgroundColor: '#67B6BB',
    alignItems: 'center',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#fff'
  },
  loginText: {
    color: '#fff',
    textAlign: 'center',
  }
})
